<?php

$conf['mysql'] = array(
		'user'     => 'croooow',
		'password' => 'coolrobot',
		'host'     => 'localhost',
		'database' => 'deep13'
		);

$conf['emergencyemails'] = array(
		'joel@example.org',
		'cambot@example.org'
		);

?>
