<?php
define('MY_CONFIG_OPTION', 'foo');
define('HOST12_3', 'foo');
?>